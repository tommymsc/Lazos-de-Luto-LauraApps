# QA de contenido (13-11-2026)

- 50 JPG presentes bajo app/src/main/assets/lazos.
- 50 hashes SHA-256 distintos: no archivos duplicados idénticos.
- Resoluciones verificadas visualmente y por PIL; no asegura que los diseños no se parezcan.
- El código de la galería usa nombres y rutas del 01 al 50, 10 por categoría.
- API 36; IDs de AdMob para release y IDs de prueba para debug.
- NO se ha ejecutado build final ni instalación en emulador.
- No se ha transferido el proyecto completo a GitHub: el conector no admite enviar archivos binarios locales.
- Faltan clave de subida válida, app-ads.txt publicado en dominio, revisión de Play y pruebas reales.
