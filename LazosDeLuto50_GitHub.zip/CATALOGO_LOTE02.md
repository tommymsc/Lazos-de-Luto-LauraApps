# Catálogo del primer bloque de 10 diseños

| Categoría | Diseño 1 | Diseño 2 |
|---|---|---|
| Elegantes | Rosa de plata | Lirio de luz |
| Sobrios | Lazo de paz | Jardín de recuerdos |
| Florales | Orquídea violeta | Lirio al atardecer |
| Religiosos | Luz de esperanza | Paloma de consuelo |
| Modernos | Luz de amor | Hasta siempre |

Nota: Los diseños se han incluido en la galería, no solo en una carpeta de imágenes. Galería, descarga, favoritos y WhatsApp usan los archivos reales del proyecto.
