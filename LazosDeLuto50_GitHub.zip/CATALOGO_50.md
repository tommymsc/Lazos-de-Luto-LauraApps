# Colección de 50 lazos

10 imágenes por categoría: Elegantes, Sobrios, Florales, Religiosos y Modernos. Categoría definida según `((id-1)%10)/2`. La numeración 01–50 está en app/src/main/assets/lazos.

Los identificadores 31–50 proceden de las 20 imágenes nuevas generadas; los 01–30 proceden de tandas previas. Este proyecto es un paquete local integrado y debe sincronizarse aún con GitHub para producir un APK allí.
