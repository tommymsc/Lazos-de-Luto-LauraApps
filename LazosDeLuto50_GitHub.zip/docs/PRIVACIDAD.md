# URL pública de la política de privacidad

https://github.com/tommymsc/Lazos-de-Luto-LauraApps/blob/main/PRIVACIDAD.md

La página se encuentra publicada como documento de GitHub. GitHub Pages aún requiere habilitación por permisos.
