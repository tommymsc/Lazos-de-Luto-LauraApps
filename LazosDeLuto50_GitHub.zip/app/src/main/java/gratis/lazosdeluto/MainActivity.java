package gratis.lazosdeluto;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.core.content.FileProvider;
import com.google.android.gms.ads.*;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.ump.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
 private final int DARK=Color.rgb(25,26,32), GOLD=Color.rgb(177,144,88);
 private LinearLayout root,grid; private boolean onlyFav=false, onlyPremium=false; private int style=0; private int page=0; private static final int PAGE_SIZE=8;
 private android.content.SharedPreferences prefs; private AdView ad; private InterstitialAd interstitial; private int successfulSaves=0;
 private final String[] groups={"Todos","Elegantes","Sobrios","Florales","Religiosos","Modernos"};
 private final String[] names={"Rosa de plata","Lirio de luz","Lazo de paz","Jardín de recuerdos","Orquídea violeta","Lirio al atardecer","Luz de esperanza","Paloma de consuelo","Luz de amor","Hasta siempre", "Bordado de lavanda","Rosa de plata nocturna", "Honor en burdeos","Mariposas del recuerdo", "Rosa de oro negro","Cruz de esperanza", "Jardín de esmeralda","Vela de amor", "Lazos de violetas","Árbol de los recuerdos","Lazo clásico negro","Lazo negro con oro","Lirio de serenidad","Jardín blanco","Rosa en memoria","Lirio de pureza","Cruz de plata","Rosa de esperanza","Azul de recuerdos","Lazo de gratitud","Camelia eterna","Lirios de cristal","Vela de memoria","Cruz de serenidad","Lirios y lavanda","Rosas del recuerdo","Luz violeta y oro","Paloma de la paz","Distinción plateada","Lirio de violeta","Flores y perlas","Cristal y lirios","Luto esencial","Recuerdo discreto","Lavanda y lirios","Rosas del alma","Fe y consuelo","Paloma y esperanza","Lazo geométrico","Corazón de luz"};
 @Override public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("favs",MODE_PRIVATE);showGallery();initAds();}
 private TextView label(String t,int size){TextView v=new TextView(this);v.setText(t);v.setTextSize(size);v.setTextColor(DARK);v.setPadding(12,12,12,12);return v;}
 private void showGallery(){
  ScrollView scroll=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(1);root.setPadding(14,18,14,18);root.setBackgroundColor(Color.rgb(249,247,243));scroll.addView(root);setContentView(scroll);
  TextView title=label("Lazos de Luto",27);title.setTypeface(null,1);root.addView(title);
  root.addView(label("50 lazos en 5 estilos · colección completa",14));
  LinearLayout tabs=new LinearLayout(this);root.addView(tabs);
  Button all=new Button(this);all.setText("Galería");tabs.addView(all,new LinearLayout.LayoutParams(0,-2,1));all.setOnClickListener(v->{onlyFav=false;onlyPremium=false;page=0;render();});
  Button fav=new Button(this);fav.setText("♥ Favoritos");tabs.addView(fav,new LinearLayout.LayoutParams(0,-2,1));fav.setOnClickListener(v->{onlyFav=true;onlyPremium=false;page=0;render();});
  Spinner sp=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,groups);sp.setAdapter(adapter);root.addView(sp);sp.setSelection(style);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int pos,long id){style=pos;page=0;render();}});
  Button featured=new Button(this);featured.setText("✦ Colección destacada");root.addView(featured);featured.setOnClickListener(v->{onlyFav=false;onlyPremium=!onlyPremium;page=0;render();});
  grid=new LinearLayout(this);grid.setOrientation(1);root.addView(grid);
  Button phrases=new Button(this);phrases.setText("💜 Mensajes de consuelo");root.addView(phrases);phrases.setOnClickListener(v->showMessages());
  Button privacy=new Button(this);privacy.setText("Privacidad y anuncios");root.addView(privacy);privacy.setOnClickListener(v->{
   new AlertDialog.Builder(this).setTitle("Privacidad y publicidad")
    .setMessage("Las imágenes están incluidas sin conexión y los favoritos se guardan solo en el dispositivo. Los anuncios de AdMob pueden tratar identificadores y datos de uso según las opciones de consentimiento aplicables. Si deseas revisar tus opciones de consentimiento, pulsa 'Opciones de anuncios'.")
    .setPositiveButton("Opciones de anuncios",(d,w)->UserMessagingPlatform.showPrivacyOptionsForm(this,err->{if(err!=null)Toast.makeText(this,"Las opciones no están disponibles ahora o no se requieren en tu región.",Toast.LENGTH_LONG).show();}))
    .setNeutralButton("Política de privacidad",(d,w)->showPrivacy())
    .setNegativeButton("Cerrar",null).show();
  });
 }
 private void showPrivacy(){
  new AlertDialog.Builder(this).setTitle("Política de privacidad · LauraApps")
   .setMessage("Lazos de Luto permite ver 50 diseños sin cuenta ni conexión, guardarlos y compartirlos cuando tú lo solicites. Los favoritos se almacenan en tu teléfono. Google AdMob puede recopilar identificadores, información de interacción y diagnósticos para anuncios, según tus opciones y la región. Se utiliza conexión a Internet para publicidad. Al compartir, los datos pasan a la aplicación elegida. Para consultas: lauraarias206@gmail.com. Más información: policies.google.com/privacy. Última revisión: noviembre de 2026.")
   .setPositiveButton("Abrir política completa",(d,w)->{Intent url=new Intent(Intent.ACTION_VIEW,Uri.parse("https://github.com/tommymsc/Lazos-de-Luto-LauraApps/blob/main/PRIVACIDAD.md"));startActivity(url);})
   .setNegativeButton("Cerrar",null).show();
 }
 private void showMessages(){
  String[][] categories={
   {"Condolencias","Te acompaño de corazón en este momento tan difícil.","Que el cariño de quienes te rodean te dé fuerzas.","Recibe un abrazo lleno de respeto y afecto."},
   {"Recuerdos","Su amor permanece en cada recuerdo compartido.","Hay personas que dejan una huella que nunca se borra.","Su memoria vivirá siempre entre quienes le amaron."},
   {"Fortaleza","Un día a la vez, con amor y paciencia.","Que encuentres serenidad en medio de esta tristeza.","No estás solo: aquí tienes una mano amiga."},
   {"Despedidas","Gracias por los recuerdos y los momentos compartidos.","Hasta siempre, con todo nuestro cariño.","Tu recuerdo seguirá iluminando nuestros días."}
  };
  String[] options=new String[categories.length];for(int i=0;i<options.length;i++)options[i]=categories[i][0];
  new AlertDialog.Builder(this).setTitle("Mensajes de consuelo").setItems(options,(d,choice)->{
   String[] values=categories[choice];String[] texts=java.util.Arrays.copyOfRange(values,1,values.length);
   new AlertDialog.Builder(this).setTitle(values[0]).setItems(texts,(dlg,idx)->{
     String message=texts[idx];new AlertDialog.Builder(this).setMessage(message)
      .setPositiveButton("Compartir",(a,b)->{Intent it=new Intent(Intent.ACTION_SEND);it.setType("text/plain");it.putExtra(Intent.EXTRA_TEXT,message);startActivity(Intent.createChooser(it,"Compartir mensaje"));})
      .setNeutralButton("Copiar",(a,b)->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Mensaje",message));Toast.makeText(this,"Mensaje copiado",Toast.LENGTH_SHORT).show();})
      .setNegativeButton("Cerrar",null).show();
   }).show();
  }).show();
 }
 private void render(){
  if(grid==null)return;
  grid.removeAllViews();
  ArrayList<Integer> filtered=new ArrayList<>();
  for(int id=1;id<=50;id++){
   if(style>0 && ((id-1)%10)/2 != style-1)continue;
   if(onlyPremium && !(id>=11 && id<=20 || id>=31 && id<=40))continue;
   if(onlyFav&&!prefs.getBoolean("f"+id,false))continue;
   filtered.add(id);
  }
  if(filtered.isEmpty()){grid.addView(label("No hay imágenes en esta sección.",16));return;}
  int pages=(filtered.size()+PAGE_SIZE-1)/PAGE_SIZE;
  page=Math.min(Math.max(page,0),pages-1);
  TextView status=label("Mostrando "+(page*PAGE_SIZE+1)+"–"+Math.min(filtered.size(),(page+1)*PAGE_SIZE)+" de "+filtered.size()+" diseños",13);
  grid.addView(status);
  for(int index=page*PAGE_SIZE;index<Math.min(filtered.size(),(page+1)*PAGE_SIZE);index++){
   final int id=filtered.get(index);
   LinearLayout item=new LinearLayout(this);item.setOrientation(1);item.setPadding(8,10,8,14);grid.addView(item);
   ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.FIT_CENTER);
   try(InputStream in=getAssets().open(path(id))){
    BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=2;
    Bitmap thumb=BitmapFactory.decodeStream(in,null,opts);
    if(thumb!=null)img.setImageBitmap(thumb);
   }catch(Exception e){img.setContentDescription("Imagen no disponible");}
   img.setContentDescription(names[id-1]);item.addView(img,new LinearLayout.LayoutParams(-1,360));
   TextView name=label(names[id-1],17);name.setTypeface(null,1);item.addView(name);
   LinearLayout actions=new LinearLayout(this);item.addView(actions);
   Button f=new Button(this);f.setText(prefs.getBoolean("f"+id,false)?"♥ Guardado":"♡ Favorito");actions.addView(f,new LinearLayout.LayoutParams(0,-2,1));f.setOnClickListener(v->{boolean b=!prefs.getBoolean("f"+id,false);prefs.edit().putBoolean("f"+id,b).apply();if(onlyFav)render();else f.setText(b?"♥ Guardado":"♡ Favorito");});
   Button save=new Button(this);save.setText("Guardar");actions.addView(save,new LinearLayout.LayoutParams(0,-2,1));save.setOnClickListener(v->save(id));
   Button share=new Button(this);share.setText("Compartir");actions.addView(share,new LinearLayout.LayoutParams(0,-2,1));share.setOnClickListener(v->share(id,false));
   Button wa=new Button(this);wa.setText("Compartir por WhatsApp");item.addView(wa);wa.setOnClickListener(v->share(id,true));
  }
  LinearLayout nav=new LinearLayout(this);grid.addView(nav);
  Button prev=new Button(this);prev.setText("◀ Anterior");prev.setEnabled(page>0);nav.addView(prev,new LinearLayout.LayoutParams(0,-2,1));prev.setOnClickListener(v->{page--;render();});
  Button next=new Button(this);next.setText("Siguiente ▶");next.setEnabled(page<pages-1);nav.addView(next,new LinearLayout.LayoutParams(0,-2,1));next.setOnClickListener(v->{page++;render();});
 }
 private String path(int i){return String.format(java.util.Locale.US,"lazos/lazo_%02d.jpg",i);}
 private void save(int i){
  Uri destination=null;
  try(InputStream in=getAssets().open(path(i))){
   android.content.ContentValues cv=new android.content.ContentValues();
   cv.put(MediaStore.Images.Media.DISPLAY_NAME,"lazo_luto_"+i+"_"+System.currentTimeMillis()+".jpg");
   cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
   cv.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/LazosDeLuto");
   cv.put(MediaStore.Images.Media.IS_PENDING,1);
   destination=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);
   if(destination==null)throw new IOException("No se pudo guardar");
   try(OutputStream out=getContentResolver().openOutputStream(destination)){
    if(out==null)throw new IOException("No se pudo abrir destino");
    byte[] buf=new byte[8192];int n;
    while((n=in.read(buf))!=-1)out.write(buf,0,n);
   }
   cv.clear();cv.put(MediaStore.Images.Media.IS_PENDING,0);
   getContentResolver().update(destination,cv,null,null);
   Toast.makeText(this,"Imagen guardada en Fotos",Toast.LENGTH_SHORT).show();
   successfulSaves++;
   if(successfulSaves%5==0 && interstitial!=null){
    InterstitialAd ready=interstitial;interstitial=null;
    ready.setFullScreenContentCallback(new FullScreenContentCallback(){
     @Override public void onAdDismissedFullScreenContent(){loadInterstitial();}
     @Override public void onAdFailedToShowFullScreenContent(com.google.android.gms.ads.AdError e){loadInterstitial();}
    });ready.show(this);
   }
  }catch(Exception e){
   if(destination!=null)try{getContentResolver().delete(destination,null,null);}catch(Exception ignored){}
   Toast.makeText(this,"No se pudo guardar la imagen",Toast.LENGTH_LONG).show();
  }
 }
 private void share(int i,boolean whatsapp){try{
  File dir=new File(getCacheDir(),"shared");dir.mkdirs();File f=new File(dir,"lazo_"+i+".jpg");try(InputStream in=getAssets().open(path(i));OutputStream out=new FileOutputStream(f)){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1)out.write(b,0,n);}
  Uri u=FileProvider.getUriForFile(this,"lazosdeluto.gratis.fileprovider",f);Intent intent=new Intent(Intent.ACTION_SEND);intent.setType("image/jpeg");intent.putExtra(Intent.EXTRA_STREAM,u);intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
  if(whatsapp){intent.setPackage("com.whatsapp");try{startActivity(intent);}catch(Exception e){intent.setPackage(null);startActivity(Intent.createChooser(intent,"Compartir imagen"));}}
  else startActivity(Intent.createChooser(intent,"Compartir imagen"));
 }catch(Exception e){Toast.makeText(this,"No se pudo compartir",Toast.LENGTH_LONG).show();}}
 private void initAds(){
  if(BuildConfig.BANNER_ID.isEmpty())return;
  ConsentRequestParameters params=new ConsentRequestParameters.Builder().build();
  UserMessagingPlatform.getConsentInformation(this).requestConsentInfoUpdate(this,params,()->{
   UserMessagingPlatform.loadAndShowConsentFormIfRequired(this,err->{if(UserMessagingPlatform.getConsentInformation(this).canRequestAds())loadBanner();});
  },err->{if(UserMessagingPlatform.getConsentInformation(this).canRequestAds())loadBanner();});
 }
 private void loadInterstitial(){if(BuildConfig.INTERSTITIAL_ID.isEmpty() || interstitial!=null)return; InterstitialAd.load(this,BuildConfig.INTERSTITIAL_ID,new AdRequest.Builder().build(),new InterstitialAdLoadCallback(){@Override public void onAdLoaded(InterstitialAd ad){interstitial=ad;} @Override public void onAdFailedToLoad(com.google.android.gms.ads.LoadAdError error){interstitial=null;}});}
 private void loadBanner(){if(ad!=null)return;MobileAds.initialize(this,status->{});ad=new AdView(this);ad.setAdUnitId(BuildConfig.BANNER_ID);ad.setAdSize(AdSize.BANNER);root.addView(ad);ad.loadAd(new AdRequest.Builder().build());loadInterstitial();}
 @Override protected void onDestroy(){if(ad!=null)ad.destroy();super.onDestroy();}
}
