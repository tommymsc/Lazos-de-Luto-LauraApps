# Colección de Lazos de Luto · 20 diseños

Se incluyen **20 imágenes JPG distintas y reales**, no dibujos generados por repetición de una plantilla.

Las categorías contienen cuatro diseños por grupo:

| Categoría | Lote 1 | Lote 3: nuevos |
|---|---|---|
| Elegantes | 01–02 | 11–12 |
| Sobrios | 03–04 | 13–14 |
| Florales | 05–06 | 15–16 |
| Religiosos | 07–08 | 17–18 |
| Modernos | 09–10 | 19–20 |

La sección **Colección destacada** filtra los diez nuevos diseños premium (11–20).

**Nota de calidad:** cinco son composiciones originales de mayor resolución; otros cinco provienen de mosaicos con diferentes escenas y tienen menos detalle nativo. Se recomienda reemplazar los cinco de mosaicos por ilustraciones individuales antes de producción.

**Pendientes:** 30 diseños adicionales, revisión visual en Android y comprobación de firma de subida para Play.
