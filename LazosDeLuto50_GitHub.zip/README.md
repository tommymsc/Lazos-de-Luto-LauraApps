# Lazos de Luto 2.0 — LauraApps

**Proyecto nuevo e independiente de Esquelas y Avisos de Luto.** 50 diseños locales, categorías, favoritos, guardado, WhatsApp/compartir y copiar frases.

- Package: `lazosdeluto.gratis`
- Version: `2.0.0` (versionCode `9`)
- compileSdk / targetSdk: `36`; minSdk: `29`
- Sin bibliotecas nativas propias (`.so`), pero **verificar compatibilidad de dependencias y reporte de 16 KB en Play Console**.
- Las imágenes son composiciones generadas para este proyecto, no fotografías ni imágenes de Esquelas.

## Compilar

1. Subir este ZIP descomprimido a un repositorio nuevo de GitHub.
2. GitHub Actions genera un APK de depuración (con IDs de anuncios de prueba).
3. Para generar el AAB release, configurar GitHub **Variables** `LAZOS_ADMOB_APP_ID` y `LAZOS_ADMOB_BANNER_ID` con los IDs originales de **Lazos de Luto**, no de otra aplicación.
4. El AAB de CI es **SIN FIRMAR PARA SUBIDA A PLAY**. Debe firmarse con una clave de subida aceptada por Google Play; si la clave de AppCreator24 no está disponible, solicitar restablecimiento de clave de subida.
5. Probar instalación, categorías, favoritos, guardar/compartir, consentimiento y anuncios antes de publicar.

## Privacidad y AdMob

- Publicar `privacy-policy.html` en una URL HTTPS pública e introducirla en Google Play y, si corresponde, AdMob.
- `app-ads.txt`: **verificar** que el publisher ID es el de la cuenta AdMob que monetiza Lazos de Luto y publicar en la raíz del dominio de desarrollador declarado en Play. El dominio debe resolver `/app-ads.txt` sin errores.
- AdMob: en release se exige App ID y banner ID propios; el debug usa IDs de prueba. La app solicita consentimiento con Google UMP antes de cargar anuncios.
- Completar Seguridad de datos según las versiones finales de los SDK y su tratamiento efectivo; no marcar respuestas automáticamente sin verificación.
- Verificar el estado de comerciante de la cuenta Play por separado.

## Política de afirmaciones engañosas

Reemplazar descripción, capturas y gráfico promocional: **NO** afirmar “las mejores 70 imágenes originales” ni cantidades diferentes a las 50 incluidas. Revisar las pantallas reales antes de enviarlas. La eliminación de 2024 no se revierte automáticamente con la compilación.

## Limitaciones por revisar

- No se ha ejecutado compilación local en este entorno: usar GitHub Actions y verificar el resultado.
- El banner se agrega al final de la vista desplazable; el proyecto prioriza sencillez y no fuerza anuncios intersticiales.

## IDs AdMob confirmados (Lazos de Luto)
- App: `ca-app-pub-2506564165861733~5189200154`
- Banner: `ca-app-pub-2506564165861733/3900408409`
- Intersticial: `ca-app-pub-2506564165861733/6482514721`
- Debug usa anuncios de prueba. Release usa los IDs reales. Intersticial solo tras cada quinta descarga guardada correctamente, si está precargado y hay consentimiento para solicitar anuncios. Nunca bloquea la descarga.
- Verificar el estado de la aplicación en AdMob y el consentimiento antes de probar anuncios reales.


## Lote 02: 10 imágenes diferentes en 5 categorías
Se añadieron dos imágenes distintas por categoría: Elegantes, Sobrios, Florales, Religiosos y Modernos. Son archivos JPEG incrustados en `app/src/main/assets/lazos/` y son los mismos que la app guarda y comparte.
Logo de instalación incluido como mipmap. La colección local ya contiene 50 JPG; antes de hacer esa afirmación en Play, compilar y verificar la distribución real de la versión final.


## Última actualización
Los 50 JPG están incluidos en `app/src/main/assets/lazos/`; `MainActivity.java` lista 50 imágenes con diez por estilo y funciones de favoritos, guardado y compartir. Aún falta probar la compilación final y subir las imágenes binarias a GitHub.
