# Renovación de la ficha de Google Play | Lazos de Luto

## Identidad
- Nombre: Lazos de Luto
- Aplicación original: lazosdeluto.gratis
- Versión: 2.0.0; versionCode 9 (confirmar que ninguna versión previa usó 9)
- API objetivo: 36; mínimo: 29
- Precio: Gratis; Contiene anuncios: Sí

## Descripción breve
Lazos de luto para guardar, recordar y compartir por WhatsApp.

## Descripción completa
Lazos de Luto ofrece una colección de 50 diseños conmemorativos organizados en cinco estilos: elegantes, sobrios, florales, religiosos y modernos.

Explora la galería sin conexión, marca tus lazos favoritos, guarda imágenes en tu teléfono y compártelas por WhatsApp u otras aplicaciones. También encontrarás mensajes breves de consuelo para copiar o compartir cuando quieras acompañar a alguien en un momento difícil.

La aplicación no requiere crear una cuenta. Algunas funciones de publicidad necesitan conexión a Internet.

## Notas versión
Lazos de Luto 2.0: nueva galería de 50 diseños conmemorativos, cinco categorías, favoritos, imágenes para guardar y compartir por WhatsApp, y mensajes de consuelo.

## Eliminar de la ficha original
- Descripción «Tenemos las mejores 70 imágenes originales y de alta calidad de lazos de luto».
- Gráfico promocional antiguo y capturas antiguas de AppCreator24.
- Toda afirmación, vídeo o imagen que no refleje exactamente la versión nueva.

## Recursos
- Icono Google Play: icono-google-play-512.png.
- Gráfico promocional: grafico-promocional-1024x500.jpg.
- Capturas: obtenerlas del APK instalado, no inventarlas.

## Seguridad de datos (revisar en Play Console)
La app almacena favoritos localmente y comparte imágenes solo a petición del usuario. Incluye Google AdMob y UMP; declarar recopilación/compartición del SDK según su documentación actual y comportamiento final. Evaluar al menos IDs de dispositivos, actividad/interacciones de anuncios, diagnósticos y ubicación aproximada si aplica. Verificar cifrado en tránsito y solicitudes de eliminación conforme al formulario de Google Play. No marcar «No recopila datos» sin completar revisión.

## Declaraciones y cuestionarios
- Declaración de anuncios: Sí.
- Público objetivo: seleccionar el público real, no inventar clasificación.
- Clasificación de contenido: responder formulario con funciones reales.
- Acceso a la app: no requiere inicio de sesión ni usuario de prueba.
- Política de privacidad: URL pública HTTPS del HTML incluido.
- App-ads.txt: debe ser accesible en la raíz del dominio de desarrollador registrado.
- Integridad / 16 KB: verificar informe tras cargar AAB.
- Firma: AAB debe usar clave de subida aceptada por Play; Google firma el paquete distribuido.
- No enviar hasta corregir infracción de metadatos y completar revisión.
