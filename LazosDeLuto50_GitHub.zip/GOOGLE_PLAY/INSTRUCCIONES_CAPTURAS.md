# Capturas reales para Google Play

Usa únicamente capturas obtenidas de la aplicación instalada en un teléfono Android; no utilices composiciones que simulen pantallas.

Sugerencia de 5 capturas:
1. Pantalla principal con logo, título y primera imagen de galería.
2. Categoría «Elegantes» con dos diseños visibles.
3. Categoría «Florales» con diseños reales.
4. Sección «Favoritos», con lazos guardados.
5. Menú «Mensajes de consuelo» y opción de compartir.

Realiza las capturas sin notificaciones, información personal ni publicidad de prueba, y comprueba que correspondan exactamente a la compilación publicada.
Resoluciones recomendadas: 1080×1920 o similar en formato vertical, PNG/JPEG.
