# Estado real — Lazos de Luto 2.0

Hecho en el proyecto fuente:
- 50 JPG distintos, categorías, favoritos, guardar, WhatsApp, mensajes de consuelo y logo.
- Android target 36, package original, configuración AdMob y UMP.
- app-ads.txt, política HTML, icono 512 y gráfico promocional 1024x500.
- Flujo CI con verificación de que hay 50 JPG y generación de APK debug/AAB sin firmar.

Pendientes EXTERNOS/NO VERIFICADOS:
1. Subir todos los archivos binarios de 50 JPG a GitHub y comprobar compilación CI de ESTA versión. El repo remoto anterior no contiene estas imágenes.
2. Instalar el APK generado, verificar estabilidad, guardado, filtros, WhatsApp, anuncios de prueba y tomar capturas reales.
3. Habilitar GitHub Pages / publicar política HTML en URL HTTPS estable y colocarla en Play.
4. Publicar app-ads.txt en raíz del dominio especificado como sitio web del desarrollador en Play, luego verificar AdMob.
5. Comprobar/restablecer clave de subida original gestionada antes por AppCreator24; firmar AAB para Play.
6. Revisar Data Safety y demás formularios Play; confirmar compatibilidad 16 KB en App Bundle Explorer.
7. Reemplazar metadatos promocionales de la versión eliminada y enviar correcciones a revisión.
8. Completar declaración de comerciante de la cuenta según aviso.

La compilación anterior de GitHub no demuestra que este ZIP con 50 JPG haya compilado.

## URL de política verificada en repositorio
https://github.com/tommymsc/Lazos-de-Luto-LauraApps/blob/main/PRIVACIDAD.md
