# Textos sugeridos para Google Play

**Nombre:** Lazos de Luto

**Descripción breve:** Lazos de luto para guardar, recordar y compartir por WhatsApp.

**Descripción completa:**
Lazos de Luto reúne 50 diseños conmemorativos que puedes explorar por estilo. Guarda tus favoritos, descarga imágenes en tu teléfono o compártelas por WhatsApp y otras aplicaciones. También puedes copiar frases breves de condolencias. Las imágenes incluidas pueden verse sin conexión.

**Notas de versión:**
Nueva galería de 50 lazos conmemorativos, categorías, favoritos y opciones para guardar y compartir imágenes.

**Antes de publicar:** actualizar gráfico promocional, capturas y política de privacidad; comprobar la coincidencia entre funciones reales y metadatos.
